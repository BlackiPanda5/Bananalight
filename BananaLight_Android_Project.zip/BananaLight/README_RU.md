# Banana Light 🍌

Простое Android-приложение: лампочка на экране и кнопка включения/выключения. Работает локально, интернет и разрешения не нужны.

## Запуск в Android Studio
1. Установите Android Studio: https://developer.android.com/studio
2. Распакуйте архив и откройте папку `BananaLight` через **File → Open**.
3. Дождитесь завершения Gradle Sync. При запросе установите Android SDK 35 и JDK, предложенные Android Studio.
4. Подключите Android-телефон с включённой «Отладкой по USB» или создайте эмулятор.
5. Нажмите **Run ▶**.

## Создать APK
В Android Studio выберите **Build → Build APK(s)**. APK появится в `app/build/outputs/apk/debug/`.

## Иконка
В `app/src/main/res/mipmap-*` находятся иконки приложения. При желании замените их на собственный рисунок банана через **Image Asset Studio** (правый клик по `app` → New → Image Asset).

## Примечание
Проект содержит исходный код и Gradle-конфигурацию, но не включает Gradle Wrapper. Android Studio сможет импортировать проект и предложить синхронизацию с установленным Gradle.
