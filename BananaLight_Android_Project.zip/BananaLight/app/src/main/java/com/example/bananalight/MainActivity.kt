package com.example.bananalight

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var isOn = false
    private lateinit var bulb: TextView
    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 25)
        window.navigationBarColor = Color.rgb(15, 18, 25)
        window.decorView.systemUiVisibility = 0
        buildScreen()
        updateBulb()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(28))
            setBackgroundColor(Color.rgb(15, 18, 25))
        }

        val brand = TextView(this).apply {
            text = "🍌  BANANA LIGHT"
            textSize = 18f
            setTextColor(Color.rgb(255, 211, 55))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(56)))

        val spacerTop = View(this)
        root.addView(spacerTop, LinearLayout.LayoutParams(1, 0, 1f))

        bulb = TextView(this).apply {
            text = "💡"
            textSize = 112f
            gravity = Gravity.CENTER
        }
        root.addView(bulb, LinearLayout.LayoutParams(-1, dp(190)))

        status = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(24))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(62)))

        toggle = Button(this).apply {
            textSize = 17f
            isAllCaps = false
            setOnClickListener {
                isOn = !isOn
                updateBulb()
            }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, dp(58))
        buttonParams.setMargins(dp(8), dp(8), dp(8), dp(8))
        root.addView(toggle, buttonParams)

        val footer = TextView(this).apply {
            text = "Нажми кнопку, чтобы включить свет"
            textSize = 13f
            setTextColor(Color.rgb(145, 153, 168))
            gravity = Gravity.CENTER
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        setContentView(root)
    }

    private fun updateBulb() {
        bulb.text = if (isOn) "💡" else "💡"
        bulb.alpha = if (isOn) 1f else 0.42f
        bulb.setShadowLayer(if (isOn) dp(24).toFloat() else 0f, 0f, 0f,
            if (isOn) Color.rgb(255, 204, 35) else Color.TRANSPARENT)
        status.text = if (isOn) "Лампочка горит" else "Лампочка выключена"
        status.setTextColor(if (isOn) Color.rgb(255, 211, 55) else Color.LTGRAY)
        toggle.text = if (isOn) "Выключить" else "Включить"
        toggle.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (isOn) Color.rgb(255, 204, 35) else Color.rgb(48, 56, 69))
        }
        toggle.setTextColor(if (isOn) Color.rgb(25, 25, 25) else Color.WHITE)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
